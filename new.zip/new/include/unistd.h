/* MinOS libc - unistd.h */

#ifndef UNISTD_H
#define UNISTD_H

#include <stddef.h>
#include <sys/types.h>

/* Standard file descriptors */
#define STDIN_FILENO  0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2

/* System calls */
int read(int fd, void *buf, size_t count);
int write(int fd, const void *buf, size_t count);
int open(const char *path, int flags);
int close(int fd);
pid_t fork(void);
int execve(const char *path, char *const argv[], char *const envp[]);
pid_t wait(int *status);
void *brk(void *addr);
void *sbrk(intptr_t increment);
pid_t getpid(void);
void _exit(int status);

#endif /* UNISTD_H */
