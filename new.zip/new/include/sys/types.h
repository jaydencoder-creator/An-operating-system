/* MinOS libc - types.h */

#ifndef SYS_TYPES_H
#define SYS_TYPES_H

typedef long pid_t;
typedef long ssize_t;
typedef unsigned long size_t;
typedef long intptr_t;
typedef long off_t;

#endif /* SYS_TYPES_H */
