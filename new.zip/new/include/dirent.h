/* MinOS libc - dirent.h */

#ifndef DIRENT_H
#define DIRENT_H

typedef struct {
    int d_fd;
    char d_name[256];
} DIR;

struct dirent {
    char d_name[256];
};

DIR *opendir(const char *name);
struct dirent *readdir(DIR *dir);
int closedir(DIR *dir);

#endif /* DIRENT_H */
