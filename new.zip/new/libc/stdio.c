/* MinOS libc - stdio.c implementation */

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>

FILE _stdin = {0, 0};
FILE _stdout = {1, 0};
FILE _stderr = {2, 0};

FILE *stdin = &_stdin;
FILE *stdout = &_stdout;
FILE *stderr = &_stderr;

FILE *fopen(const char *path, const char *mode) {
    int flags = 0;
    if (mode[0] == 'r') flags = O_RDONLY;
    else if (mode[0] == 'w') flags = O_WRONLY | O_CREAT | O_TRUNC;
    else if (mode[0] == 'a') flags = O_WRONLY | O_CREAT | O_APPEND;

    int fd = open(path, flags);
    if (fd < 0) return NULL;

    FILE *f = malloc(sizeof(FILE));
    if (!f) {
        close(fd);
        return NULL;
    }

    f->fd = fd;
    f->flags = flags;
    return f;
}

int fclose(FILE *stream) {
    if (!stream) return EOF;
    close(stream->fd);
    free(stream);
    return 0;
}

size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream) {
    if (!stream || !ptr) return 0;
    size_t total = size * nmemb;
    int ret = read(stream->fd, ptr, total);
    return (ret > 0) ? (ret / size) : 0;
}

size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream) {
    if (!stream || !ptr) return 0;
    size_t total = size * nmemb;
    int ret = write(stream->fd, ptr, total);
    return (ret > 0) ? (ret / size) : 0;
}

int fputc(int c, FILE *stream) {
    char ch = (char)c;
    return (write(stream->fd, &ch, 1) == 1) ? c : EOF;
}

int fgetc(FILE *stream) {
    char c;
    if (fread(&c, 1, 1, stream) == 1) {
        return (unsigned char)c;
    }
    return EOF;
}

char *fgets(char *s, int size, FILE *stream) {
    if (!s || size <= 0 || !stream) return NULL;
    int i = 0;
    int c;
    while (i < size - 1) {
        c = fgetc(stream);
        if (c == EOF) {
            if (i == 0) return NULL;
            break;
        }
        s[i++] = (char)c;
        if (c == '\n') break;
    }
    s[i] = '\0';
    return s;
}

int fflush(FILE *stream) {
    (void)stream;
    /* Simplified - in real implementation would flush buffer */
    return 0;
}

int fputs(const char *s, FILE *stream) {
    if (!s || !stream) return EOF;
    size_t len = strlen(s);
    return (write(stream->fd, s, len) == len) ? 0 : EOF;
}

int vfprintf(FILE *stream, const char *format, va_list args) {
    int written = 0;
    while (*format) {
        if (*format == '%') {
            format++;
            switch (*format) {
                case 'd':
                case 'i': {
                    int val = va_arg(args, int);
                    char buf[32];
                    itoa(val, buf, 10);
                    written += write(stream->fd, buf, strlen(buf));
                    break;
                }
                case 's': {
                    char *str = va_arg(args, char *);
                    written += write(stream->fd, str, strlen(str));
                    break;
                }
                case 'c': {
                    char c = va_arg(args, int);
                    written += write(stream->fd, &c, 1);
                    break;
                }
                case '%':
                    written += write(stream->fd, "%", 1);
                    break;
            }
        } else {
            written += write(stream->fd, format, 1);
        }
        format++;
    }
    return written;
}

/* Simple printf implementation */
int printf(const char *format, ...) {
    va_list args;
    va_start(args, format);
    int ret = vfprintf(stdout, format, args);
    va_end(args);
    return ret;
}

int fprintf(FILE *stream, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int ret = vfprintf(stream, format, args);
    va_end(args);
    return ret;
}
