/* MinOS libc - dirent.c implementation */

#include <dirent.h>
#include <stdlib.h>

DIR *opendir(const char *name) {
    (void)name;
    DIR *dir = malloc(sizeof(DIR));
    if (dir) {
        dir->d_fd = -1;
        dir->d_name[0] = '\0';
    }
    return dir;
}

struct dirent *readdir(DIR *dir) {
    (void)dir;
    /* Simplified - would read from filesystem */
    return NULL;
}

int closedir(DIR *dir) {
    if (dir) {
        free(dir);
        return 0;
    }
    return -1;
}
