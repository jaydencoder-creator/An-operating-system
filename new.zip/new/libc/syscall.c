/* MinOS libc - System call wrapper implementation */

#include "syscall.h"

/* System call wrapper macros */
#define SYSCALL0(num) \
    ({ \
        int ret; \
        __asm__ volatile ("int $0x80" \
            : "=a" (ret) \
            : "a" (num) \
            : "memory"); \
        ret; \
    })

#define SYSCALL1(num, arg1) \
    ({ \
        int ret; \
        __asm__ volatile ("int $0x80" \
            : "=a" (ret) \
            : "a" (num), "b" ((long)(arg1)) \
            : "memory"); \
        ret; \
    })

#define SYSCALL2(num, arg1, arg2) \
    ({ \
        int ret; \
        __asm__ volatile ("int $0x80" \
            : "=a" (ret) \
            : "a" (num), "b" ((long)(arg1)), "c" ((long)(arg2)) \
            : "memory"); \
        ret; \
    })

#define SYSCALL3(num, arg1, arg2, arg3) \
    ({ \
        int ret; \
        __asm__ volatile ("int $0x80" \
            : "=a" (ret) \
            : "a" (num), "b" ((long)(arg1)), "c" ((long)(arg2)), "d" ((long)(arg3)) \
            : "memory"); \
        ret; \
    })

/* System call numbers (from kernel) */
#define SYS_EXIT    1
#define SYS_READ    2
#define SYS_WRITE   3
#define SYS_OPEN    4
#define SYS_CLOSE   5
#define SYS_FORK    6
#define SYS_EXEC    7
#define SYS_WAIT    8
#define SYS_BRK     9
#define SYS_SBRK    10
#define SYS_STAT    11
#define SYS_GETPID  12

int sys_read(int fd, void *buf, size_t count) {
    return SYSCALL3(SYS_READ, fd, buf, count);
}

int sys_write(int fd, const void *buf, size_t count) {
    return SYSCALL3(SYS_WRITE, fd, buf, count);
}

int sys_open(const char *path, int flags) {
    return SYSCALL2(SYS_OPEN, path, flags);
}

int sys_close(int fd) {
    return SYSCALL1(SYS_CLOSE, fd);
}

pid_t sys_fork(void) {
    return SYSCALL0(SYS_FORK);
}

int sys_exec(const char *path, char *const argv[]) {
    return SYSCALL2(SYS_EXEC, path, argv);
}

pid_t sys_wait(int *status) {
    return SYSCALL1(SYS_WAIT, status);
}

void *sys_brk(void *addr) {
    return (void *)SYSCALL1(SYS_BRK, addr);
}

void *sys_sbrk(intptr_t increment) {
    return (void *)SYSCALL1(SYS_SBRK, increment);
}

int sys_stat(const char *path, void *stat_buf) {
    return SYSCALL2(SYS_STAT, path, stat_buf);
}

pid_t sys_getpid(void) {
    return SYSCALL0(SYS_GETPID);
}

int sys_exit(int status) {
    SYSCALL1(SYS_EXIT, status);
    return 0; /* Never reached */
}
