/* MinOS libc - System call interface */

#ifndef LIBC_SYSCALL_H
#define LIBC_SYSCALL_H

#include <stddef.h>
#include <sys/types.h>

int sys_read(int fd, void *buf, size_t count);
int sys_write(int fd, const void *buf, size_t count);
int sys_open(const char *path, int flags);
int sys_close(int fd);
pid_t sys_fork(void);
int sys_exec(const char *path, char *const argv[]);
pid_t sys_wait(int *status);
void *sys_brk(void *addr);
void *sys_sbrk(intptr_t increment);
int sys_stat(const char *path, void *stat_buf);
pid_t sys_getpid(void);
int sys_exit(int status);

#endif /* LIBC_SYSCALL_H */
