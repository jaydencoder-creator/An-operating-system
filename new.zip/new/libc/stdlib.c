/* MinOS libc - stdlib.c implementation */

#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* Simple memory allocator using sbrk */
static void *heap_top = NULL;

void *malloc(size_t size) {
    if (size == 0) return NULL;

    /* Align to 8 bytes */
    size = (size + 7) & ~7;

    void *ptr = sbrk(size);
    if (ptr == (void *)-1) {
        return NULL;
    }

    if (!heap_top) {
        heap_top = ptr;
    }

    return ptr;
}

void free(void *ptr) {
    /* Simplified - in real implementation would track and coalesce blocks */
    (void)ptr;
}

void *realloc(void *ptr, size_t size) {
    if (!ptr) return malloc(size);
    if (size == 0) {
        free(ptr);
        return NULL;
    }

    /* Simplified - would need to track block sizes */
    void *new_ptr = malloc(size);
    if (!new_ptr) return NULL;

    /* Copy data (would need block size) */
    memcpy(new_ptr, ptr, size);
    free(ptr);
    return new_ptr;
}

void *calloc(size_t nmemb, size_t size) {
    size_t total = nmemb * size;
    void *ptr = malloc(total);
    if (ptr) {
        memset(ptr, 0, total);
    }
    return ptr;
}

void exit(int status) {
    _exit(status);
}

int atoi(const char *nptr) {
    int result = 0;
    int sign = 1;

    if (*nptr == '-') {
        sign = -1;
        nptr++;
    } else if (*nptr == '+') {
        nptr++;
    }

    while (*nptr >= '0' && *nptr <= '9') {
        result = result * 10 + (*nptr - '0');
        nptr++;
    }

    return sign * result;
}

char *itoa(int value, char *str, int base) {
    char *ptr = str;
    int negative = 0;

    if (value < 0 && base == 10) {
        negative = 1;
        value = -value;
    }

    if (value == 0) {
        *ptr++ = '0';
        *ptr = '\0';
        return str;
    }

    while (value > 0) {
        int digit = value % base;
        *ptr++ = (digit < 10) ? ('0' + digit) : ('A' + digit - 10);
        value /= base;
    }

    if (negative) {
        *ptr++ = '-';
    }

    *ptr = '\0';

    /* Reverse string */
    char *start = str;
    char *end = ptr - 1;
    while (start < end) {
        char temp = *start;
        *start = *end;
        *end = temp;
        start++;
        end--;
    }

    return str;
}
