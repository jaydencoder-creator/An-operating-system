/* MinOS libc - unistd.c implementation */

#include <unistd.h>
#include <syscall.h>

int read(int fd, void *buf, size_t count) {
    return sys_read(fd, buf, count);
}

int write(int fd, const void *buf, size_t count) {
    return sys_write(fd, buf, count);
}

int open(const char *path, int flags) {
    return sys_open(path, flags);
}

int close(int fd) {
    return sys_close(fd);
}

pid_t fork(void) {
    return sys_fork();
}

int execve(const char *path, char *const argv[], char *const envp[]) {
    (void)envp;
    return sys_exec(path, argv);
}

pid_t wait(int *status) {
    return sys_wait(status);
}

void *brk(void *addr) {
    return sys_brk(addr);
}

void *sbrk(intptr_t increment) {
    return sys_sbrk(increment);
}

pid_t getpid(void) {
    return sys_getpid();
}

void _exit(int status) {
    sys_exit(status);
    while(1); /* Should not reach here */
}
