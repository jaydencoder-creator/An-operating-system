/* MinOS Kernel - Virtual File System Implementation */

#include "vfs.h"
#include "print.h"
#include <stddef.h>
#include <string.h>

static file_descriptor_t file_descriptors[MAX_FILES];
static int next_fd = 3; /* 0, 1, 2 are stdin, stdout, stderr */

/**
 * Initialize VFS
 */
void vfs_init(void) {
    int i;
    for (i = 0; i < MAX_FILES; i++) {
        file_descriptors[i].inode = -1;
        file_descriptors[i].offset = 0;
        file_descriptors[i].flags = 0;
        file_descriptors[i].refcount = 0;
    }

    /* Set up stdin, stdout, stderr */
    file_descriptors[0].inode = 0; /* stdin */
    file_descriptors[0].flags = O_RDONLY;
    file_descriptors[0].refcount = 1;

    file_descriptors[1].inode = 1; /* stdout */
    file_descriptors[1].flags = O_WRONLY;
    file_descriptors[1].refcount = 1;

    file_descriptors[2].inode = 2; /* stderr */
    file_descriptors[2].flags = O_WRONLY;
    file_descriptors[2].refcount = 1;
}

/**
 * Allocate file descriptor
 */
static int allocate_fd(void) {
    int i;
    for (i = next_fd; i < MAX_FILES; i++) {
        if (file_descriptors[i].refcount == 0) {
            next_fd = i + 1;
            return i;
        }
    }
    for (i = 3; i < next_fd; i++) {
        if (file_descriptors[i].refcount == 0) {
            return i;
        }
    }
    return -1; /* No free file descriptors */
}

/**
 * Open file
 */
int vfs_open(const char *path, int flags) {
    int fd = allocate_fd();
    if (fd < 0) {
        return -1;
    }

    /* Simplified file opening */
    /* In real implementation, would:
     * 1. Resolve path
     * 2. Check permissions
     * 3. Find or create inode
     * 4. Create file descriptor
     */

    file_descriptors[fd].inode = 100; /* Placeholder */
    file_descriptors[fd].offset = 0;
    file_descriptors[fd].flags = flags;
    file_descriptors[fd].refcount = 1;

    return fd;
}

/**
 * Close file descriptor
 */
int vfs_close(int fd) {
    if (fd < 0 || fd >= MAX_FILES) {
        return -1;
    }

    if (file_descriptors[fd].refcount == 0) {
        return -1; /* Already closed */
    }

    file_descriptors[fd].refcount--;
    if (file_descriptors[fd].refcount == 0) {
        file_descriptors[fd].inode = -1;
        file_descriptors[fd].offset = 0;
        file_descriptors[fd].flags = 0;
    }

    return 0;
}

/**
 * Read from file descriptor
 */
int vfs_read(int fd, void *buf, size_t count) {
    if (fd < 0 || fd >= MAX_FILES) {
        return -1;
    }

    if (file_descriptors[fd].refcount == 0) {
        return -1; /* Invalid file descriptor */
    }

    if (fd == 0) {
        /* stdin - simplified, would read from keyboard */
        return 0;
    }

    /* In real implementation, would read from file */
    /* For now, return 0 (EOF) */
    return 0;
}

/**
 * Write to file descriptor
 */
int vfs_write(int fd, const void *buf, size_t count) {
    if (fd < 0 || fd >= MAX_FILES) {
        return -1;
    }

    if (file_descriptors[fd].refcount == 0) {
        return -1; /* Invalid file descriptor */
    }

    if (fd == 1 || fd == 2) {
        /* stdout/stderr - write to console */
        const char *str = (const char *)buf;
        int i;
        for (i = 0; i < count && str[i]; i++) {
            print_char(str[i]);
        }
        return i;
    }

    /* In real implementation, would write to file */
    return count;
}

/**
 * Seek in file
 */
int vfs_seek(int fd, int offset, int whence) {
    if (fd < 0 || fd >= MAX_FILES) {
        return -1;
    }

    if (file_descriptors[fd].refcount == 0) {
        return -1;
    }

    /* Simplified seeking */
    file_descriptors[fd].offset = offset;
    return 0;
}

/**
 * Get file size
 */
size_t vfs_get_size(int fd) {
    if (fd < 0 || fd >= MAX_FILES) {
        return 0;
    }

    if (file_descriptors[fd].refcount == 0) {
        return 0;
    }

    /* Simplified */
    return 0;
}
