/* MinOS Kernel - Device Drivers */

#ifndef DRIVER_H
#define DRIVER_H

/* Driver types */
typedef enum {
    DRIVER_KEYBOARD,
    DRIVER_MOUSE,
    DRIVER_DISK,
    DRIVER_NETWORK,
    DRIVER_TIMER
} driver_type_t;

/* Driver operations */
void driver_init(void);
void driver_register(driver_type_t type, void *ops);
void *driver_get(driver_type_t type);

#endif /* DRIVER_H */
