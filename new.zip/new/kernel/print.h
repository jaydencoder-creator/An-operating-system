/* MinOS Kernel - Print Utilities */

#ifndef PRINT_H
#define PRINT_H

void print_string(const char *str);
void print_char(char c);
void print_int(int value);
void print_hex(unsigned int value);
void clear_screen(void);
void print_error(const char *msg);

#endif /* PRINT_H */
