/* MinOS Kernel - System Calls */

#ifndef SYSCALL_H
#define SYSCALL_H

#include <stddef.h>

/* System call numbers */
#define SYS_EXIT    1
#define SYS_READ    2
#define SYS_WRITE   3
#define SYS_OPEN    4
#define SYS_CLOSE   5
#define SYS_FORK    6
#define SYS_EXEC    7
#define SYS_WAIT    8
#define SYS_BRK     9
#define SYS_SBRK    10
#define SYS_STAT    11
#define SYS_GETPID  12
#define SYS_YIELD   13

/* System call functions */
void syscall_init(void);
int syscall_handler(int number, int arg1, int arg2, int arg3);

/* System call wrappers */
int sys_exit(int status);
int sys_read(int fd, void *buf, size_t count);
int sys_write(int fd, const void *buf, size_t count);
int sys_open(const char *path, int flags);
int sys_close(int fd);
int sys_fork(void);
int sys_exec(const char *path, char *const argv[]);
int sys_wait(int *status);
void *sys_brk(void *addr);
void *sys_sbrk(intptr_t increment);
int sys_stat(const char *path, void *stat_buf);
int sys_getpid(void);
int sys_yield(void);

#endif /* SYSCALL_H */
