/* MinOS Kernel - Memory Management Implementation */

#include "memory.h"
#include "print.h"
#include <stddef.h>
#include <stdint.h>

#define PAGE_SIZE 4096
#define HEAP_START 0x100000  /* 1MB */
#define HEAP_SIZE 0x400000   /* 4MB */

/* Simple memory block header */
typedef struct mem_block {
    size_t size;
    int free;
    struct mem_block *next;
} mem_block_t;

static mem_block_t *heap_start = NULL;
static size_t total_memory = 0;
static size_t free_memory = 0;

/**
 * Initialize memory management
 */
void memory_init(void) {
    /* Initialize heap */
    heap_start = (mem_block_t *)HEAP_START;
    heap_start->size = HEAP_SIZE - sizeof(mem_block_t);
    heap_start->free = 1;
    heap_start->next = NULL;

    total_memory = HEAP_SIZE;
    free_memory = heap_start->size;

    /* Initialize virtual memory management */
    vmm_init();
}

/**
 * Find free block (first-fit algorithm)
 */
static mem_block_t *find_free_block(size_t size) {
    mem_block_t *current = heap_start;
    while (current) {
        if (current->free && current->size >= size) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

/**
 * Allocate memory (kernel malloc)
 */
void *kmalloc(size_t size) {
    if (size == 0) return NULL;

    /* Align to 8 bytes */
    size = (size + 7) & ~7;

    mem_block_t *block = find_free_block(size + sizeof(mem_block_t));
    if (!block) {
        return NULL; /* Out of memory */
    }

    /* Split block if large enough */
    if (block->size >= size + sizeof(mem_block_t) + 8) {
        mem_block_t *new_block = (mem_block_t *)((char *)block + sizeof(mem_block_t) + size);
        new_block->size = block->size - size - sizeof(mem_block_t);
        new_block->free = 1;
        new_block->next = block->next;
        block->next = new_block;
        block->size = size;
    }

    block->free = 0;
    free_memory -= (block->size + sizeof(mem_block_t));

    return (void *)((char *)block + sizeof(mem_block_t));
}

/**
 * Free memory (kernel free)
 */
void kfree(void *ptr) {
    if (!ptr) return;

    mem_block_t *block = (mem_block_t *)((char *)ptr - sizeof(mem_block_t));
    block->free = 1;
    free_memory += (block->size + sizeof(mem_block_t));

    /* Coalesce with next block if free */
    if (block->next && block->next->free) {
        block->size += sizeof(mem_block_t) + block->next->size;
        block->next = block->next->next;
    }
}

/**
 * Reallocate memory
 */
void *krealloc(void *ptr, size_t size) {
    if (!ptr) return kmalloc(size);
    if (size == 0) {
        kfree(ptr);
        return NULL;
    }

    mem_block_t *block = (mem_block_t *)((char *)ptr - sizeof(mem_block_t));
    if (block->size >= size) {
        return ptr; /* Already large enough */
    }

    void *new_ptr = kmalloc(size);
    if (!new_ptr) return NULL;

    /* Copy data */
    char *old = (char *)ptr;
    char *new = (char *)new_ptr;
    size_t copy_size = (block->size < size) ? block->size : size;
    int i;
    for (i = 0; i < copy_size; i++) {
        new[i] = old[i];
    }

    kfree(ptr);
    return new_ptr;
}

/**
 * Physical memory allocator (simplified)
 */
void *pmm_alloc(size_t pages) {
    /* Simplified implementation */
    static uint32_t pmm_next = 0x200000; /* Start at 2MB */
    void *addr = (void *)pmm_next;
    pmm_next += pages * PAGE_SIZE;
    return addr;
}

/**
 * Physical memory free
 */
void pmm_free(void *ptr, size_t pages) {
    /* Simplified - in real implementation, track free pages */
    (void)ptr;
    (void)pages;
}

/**
 * Virtual memory manager initialization
 */
void vmm_init(void) {
    /* Initialize page tables, etc. */
    /* Simplified for now */
}

/**
 * Map virtual address to physical address
 */
void *vmm_map(void *phys_addr, size_t size) {
    /* Simplified - just return physical address for now */
    return phys_addr;
}

/**
 * Unmap virtual address
 */
void vmm_unmap(void *virt_addr, size_t size) {
    /* Simplified */
    (void)virt_addr;
    (void)size;
}

/**
 * Get total memory
 */
size_t memory_get_total(void) {
    return total_memory;
}

/**
 * Get free memory
 */
size_t memory_get_free(void) {
    return free_memory;
}

/**
 * Get used memory
 */
size_t memory_get_used(void) {
    return total_memory - free_memory;
}
