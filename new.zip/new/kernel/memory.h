/* MinOS Kernel - Memory Management */

#ifndef MEMORY_H
#define MEMORY_H

#include <stddef.h>

/* Memory management functions */
void memory_init(void);
void *kmalloc(size_t size);
void kfree(void *ptr);
void *krealloc(void *ptr, size_t size);

/* Physical memory */
void *pmm_alloc(size_t pages);
void pmm_free(void *ptr, size_t pages);

/* Virtual memory */
void vmm_init(void);
void *vmm_map(void *phys_addr, size_t size);
void vmm_unmap(void *virt_addr, size_t size);

/* Memory statistics */
size_t memory_get_total(void);
size_t memory_get_free(void);
size_t memory_get_used(void);

#endif /* MEMORY_H */
