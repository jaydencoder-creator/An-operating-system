/* MinOS Kernel - Device Driver Implementation */

#include "driver.h"
#include "print.h"
#include <stddef.h>

#define MAX_DRIVERS 32

static void *drivers[MAX_DRIVERS];

/**
 * Initialize drivers
 */
void driver_init(void) {
    int i;
    for (i = 0; i < MAX_DRIVERS; i++) {
        drivers[i] = NULL;
    }

    /* Initialize basic drivers */
    /* In real implementation, would probe hardware and load drivers */
}

/**
 * Register driver
 */
void driver_register(driver_type_t type, void *ops) {
    if (type < MAX_DRIVERS) {
        drivers[type] = ops;
    }
}

/**
 * Get driver
 */
void *driver_get(driver_type_t type) {
    if (type < MAX_DRIVERS) {
        return drivers[type];
    }
    return NULL;
}
