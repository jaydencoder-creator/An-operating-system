/* MinOS Kernel - System Call Implementation */

#include "syscall.h"
#include "process.h"
#include "vfs.h"
#include "print.h"
#include <stddef.h>

/* System call table */
static int (*syscall_table[])(int, int, int) = {
    NULL,          /* 0 - unused */
    (int (*)(int, int, int))sys_exit,
    (int (*)(int, int, int))sys_read,
    (int (*)(int, int, int))sys_write,
    (int (*)(int, int, int))sys_open,
    (int (*)(int, int, int))sys_close,
    (int (*)(int, int, int))sys_fork,
    (int (*)(int, int, int))sys_exec,
    (int (*)(int, int, int))sys_wait,
    (int (*)(int, int, int))sys_brk,
    (int (*)(int, int, int))sys_sbrk,
    (int (*)(int, int, int))sys_stat,
    (int (*)(int, int, int))sys_getpid,
    (int (*)(int, int, int))sys_yield,
};

/**
 * Initialize system calls
 */
void syscall_init(void) {
    /* Set up system call interrupt handler */
    /* In real implementation, would configure IDT */
}

/**
 * System call handler
 */
int syscall_handler(int number, int arg1, int arg2, int arg3) {
    if (number < 1 || number >= (sizeof(syscall_table) / sizeof(syscall_table[0]))) {
        return -1; /* Invalid system call */
    }

    if (!syscall_table[number]) {
        return -1; /* Unimplemented */
    }

    return syscall_table[number](arg1, arg2, arg3);
}

/**
 * Exit process
 */
int sys_exit(int status) {
    process_exit(status);
    return 0;
}

/**
 * Read from file descriptor
 */
int sys_read(int fd, void *buf, size_t count) {
    if (!buf || count == 0) return -1;
    return vfs_read(fd, buf, count);
}

/**
 * Write to file descriptor
 */
int sys_write(int fd, const void *buf, size_t count) {
    if (!buf || count == 0) return -1;
    return vfs_write(fd, buf, count);
}

/**
 * Open file
 */
int sys_open(const char *path, int flags) {
    if (!path) return -1;
    return vfs_open(path, flags);
}

/**
 * Close file descriptor
 */
int sys_close(int fd) {
    return vfs_close(fd);
}

/**
 * Fork process (simplified - not fully implemented)
 */
int sys_fork(void) {
    /* In real implementation, would duplicate current process */
    return -1; /* Not implemented */
}

/**
 * Execute program (simplified - not fully implemented)
 */
int sys_exec(const char *path, char *const argv[]) {
    (void)path;
    (void)argv;
    return -1; /* Not implemented */
}

/**
 * Wait for child process
 */
int sys_wait(int *status) {
    (void)status;
    return -1; /* Not implemented */
}

/**
 * Set break point (memory allocation)
 */
void *sys_brk(void *addr) {
    (void)addr;
    return NULL; /* Simplified */
}

/**
 * Increment break point
 */
void *sys_sbrk(intptr_t increment) {
    (void)increment;
    return NULL; /* Simplified */
}

/**
 * Get file status
 */
int sys_stat(const char *path, void *stat_buf) {
    (void)path;
    (void)stat_buf;
    return -1; /* Not implemented */
}

/**
 * Get process ID
 */
int sys_getpid(void) {
    process_t *proc = process_get_current();
    return proc ? proc->pid : 0;
}

/**
 * Yield CPU
 */
int sys_yield(void) {
    scheduler_yield();
    return 0;
}
