/* MinOS Kernel - Print Utilities Implementation */

#include "print.h"
#include "driver.h"

/* VGA text mode buffer */
#define VGA_WIDTH 80
#define VGA_HEIGHT 25
#define VGA_MEMORY 0xB8000

static volatile char *vga_buffer = (volatile char *)VGA_MEMORY;
static int cursor_x = 0;
static int cursor_y = 0;
static char color = 0x07; /* Light grey on black */

/**
 * Clear the screen
 */
void clear_screen(void) {
    int i;
    for (i = 0; i < VGA_WIDTH * VGA_HEIGHT * 2; i += 2) {
        vga_buffer[i] = ' ';
        vga_buffer[i + 1] = color;
    }
    cursor_x = 0;
    cursor_y = 0;
}

/**
 * Scroll screen up one line
 */
static void scroll(void) {
    int i;
    /* Move all lines up */
    for (i = 0; i < (VGA_HEIGHT - 1) * VGA_WIDTH * 2; i++) {
        vga_buffer[i] = vga_buffer[i + VGA_WIDTH * 2];
    }
    /* Clear last line */
    for (i = (VGA_HEIGHT - 1) * VGA_WIDTH * 2; i < VGA_HEIGHT * VGA_WIDTH * 2; i += 2) {
        vga_buffer[i] = ' ';
        vga_buffer[i + 1] = color;
    }
    cursor_y--;
}

/**
 * Update cursor position
 */
static void update_cursor(void) {
    unsigned short pos = cursor_y * VGA_WIDTH + cursor_x;
    /* Update hardware cursor (requires I/O ports) */
    /* Simplified for now */
}

/**
 * Print a single character
 */
void print_char(char c) {
    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
        if (cursor_y >= VGA_HEIGHT) {
            scroll();
        }
    } else if (c == '\r') {
        cursor_x = 0;
    } else if (c == '\t') {
        cursor_x = (cursor_x + 4) & ~(4 - 1);
        if (cursor_x >= VGA_WIDTH) {
            cursor_x = 0;
            cursor_y++;
        }
    } else {
        int pos = (cursor_y * VGA_WIDTH + cursor_x) * 2;
        vga_buffer[pos] = c;
        vga_buffer[pos + 1] = color;
        cursor_x++;
        if (cursor_x >= VGA_WIDTH) {
            cursor_x = 0;
            cursor_y++;
            if (cursor_y >= VGA_HEIGHT) {
                scroll();
            }
        }
    }
    update_cursor();
}

/**
 * Print a string
 */
void print_string(const char *str) {
    while (*str) {
        print_char(*str++);
    }
}

/**
 * Print an integer
 */
void print_int(int value) {
    char buffer[12];
    int i = 0;
    int negative = 0;

    if (value < 0) {
        negative = 1;
        value = -value;
    }

    if (value == 0) {
        buffer[i++] = '0';
    } else {
        while (value > 0) {
            buffer[i++] = '0' + (value % 10);
            value /= 10;
        }
    }

    if (negative) {
        buffer[i++] = '-';
    }

    /* Reverse string */
    int j;
    for (j = 0; j < i / 2; j++) {
        char temp = buffer[j];
        buffer[j] = buffer[i - 1 - j];
        buffer[i - 1 - j] = temp;
    }

    buffer[i] = '\0';
    print_string(buffer);
}

/**
 * Print a hex value
 */
void print_hex(unsigned int value) {
    print_string("0x");
    if (value == 0) {
        print_char('0');
        return;
    }

    char buffer[9];
    int i;
    for (i = 7; i >= 0; i--) {
        int digit = (value >> (i * 4)) & 0xF;
        buffer[7 - i] = (digit < 10) ? ('0' + digit) : ('A' + digit - 10);
    }
    buffer[8] = '\0';

    /* Skip leading zeros */
    i = 0;
    while (i < 7 && buffer[i] == '0') i++;
    print_string(&buffer[i]);
}

/**
 * Print error message
 */
void print_error(const char *msg) {
    char old_color = color;
    color = 0x04; /* Red on black */
    print_string("ERROR: ");
    print_string(msg);
    print_string("\n");
    color = old_color;
}
