/* MinOS Kernel - Process Management */

#ifndef PROCESS_H
#define PROCESS_H

#include <stdint.h>

#define MAX_PROCESSES 256
#define STACK_SIZE 0x10000  /* 64KB */

/* Process states */
typedef enum {
    PROCESS_NEW,
    PROCESS_READY,
    PROCESS_RUNNING,
    PROCESS_BLOCKED,
    PROCESS_TERMINATED
} process_state_t;

/* Process control block */
typedef struct process {
    uint32_t pid;
    process_state_t state;
    uint32_t priority;
    void *stack;
    void *heap;
    uint32_t registers[8];  /* General purpose registers */
    struct process *next;
} process_t;

/* Process management functions */
void process_init(void);
process_t *process_create(void (*entry)(void));
void process_create_init(void);
void process_exit(int status);
process_t *process_get_current(void);
void process_set_current(process_t *proc);

/* Scheduler */
void scheduler_start(void);
void scheduler_yield(void);
void scheduler_schedule(void);

#endif /* PROCESS_H */
