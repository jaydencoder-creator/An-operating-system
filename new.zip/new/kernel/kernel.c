/* MinOS Kernel - Main Kernel Entry Point */

#include "kernel.h"
#include "memory.h"
#include "process.h"
#include "syscall.h"
#include "vfs.h"
#include "driver.h"
#include "print.h"

/* Kernel version information */
#define KERNEL_VERSION_MAJOR 1
#define KERNEL_VERSION_MINOR 0
#define KERNEL_VERSION_PATCH 0

/* Kernel initialization state */
static int kernel_initialized = 0;

/**
 * Early kernel initialization
 * Called from bootloader
 */
void kernel_main(void) {
    /* Clear screen and print banner */
    clear_screen();
    print_string("MinOS Kernel v");
    print_int(KERNEL_VERSION_MAJOR);
    print_string(".");
    print_int(KERNEL_VERSION_MINOR);
    print_string(".");
    print_int(KERNEL_VERSION_PATCH);
    print_string("\nInitializing...\n");

    /* Initialize memory management */
    print_string("[1/6] Initializing memory management...\n");
    memory_init();
    print_string("        Memory initialized\n");

    /* Initialize drivers */
    print_string("[2/6] Initializing device drivers...\n");
    driver_init();
    print_string("        Drivers initialized\n");

    /* Initialize virtual file system */
    print_string("[3/6] Initializing virtual file system...\n");
    vfs_init();
    print_string("        VFS initialized\n");

    /* Initialize system calls */
    print_string("[4/6] Initializing system calls...\n");
    syscall_init();
    print_string("        System calls initialized\n");

    /* Initialize process management */
    print_string("[5/6] Initializing process management...\n");
    process_init();
    print_string("        Process management initialized\n");

    /* Create init process */
    print_string("[6/6] Creating init process...\n");
    process_create_init();
    print_string("        Init process created\n");

    kernel_initialized = 1;
    print_string("\nMinOS Kernel initialized successfully!\n");
    print_string("Starting system...\n\n");

    /* Start scheduler */
    scheduler_start();
}

/**
 * Get kernel version
 */
void kernel_get_version(int *major, int *minor, int *patch) {
    if (major) *major = KERNEL_VERSION_MAJOR;
    if (minor) *minor = KERNEL_VERSION_MINOR;
    if (patch) *patch = KERNEL_VERSION_PATCH;
}

/**
 * Check if kernel is initialized
 */
int kernel_is_initialized(void) {
    return kernel_initialized;
}
