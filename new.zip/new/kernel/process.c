/* MinOS Kernel - Process Management Implementation */

#include "process.h"
#include "memory.h"
#include "print.h"
#include <stddef.h>

static process_t processes[MAX_PROCESSES];
static int next_pid = 1;
static process_t *current_process = NULL;
static process_t *ready_queue = NULL;

/**
 * Initialize process management
 */
void process_init(void) {
    int i;
    for (i = 0; i < MAX_PROCESSES; i++) {
        processes[i].pid = 0;
        processes[i].state = PROCESS_TERMINATED;
    }
    current_process = NULL;
    ready_queue = NULL;
}

/**
 * Create a new process
 */
process_t *process_create(void (*entry)(void)) {
    int i;
    process_t *proc = NULL;

    /* Find free slot */
    for (i = 0; i < MAX_PROCESSES; i++) {
        if (processes[i].state == PROCESS_TERMINATED) {
            proc = &processes[i];
            break;
        }
    }

    if (!proc) {
        return NULL; /* No free slots */
    }

    /* Allocate stack */
    proc->stack = kmalloc(STACK_SIZE);
    if (!proc->stack) {
        return NULL;
    }

    /* Initialize process */
    proc->pid = next_pid++;
    proc->state = PROCESS_READY;
    proc->priority = 5; /* Default priority */
    proc->heap = NULL;
    proc->next = NULL;

    /* Set up initial stack pointer (simplified) */
    /* In real implementation, set up registers and stack frame */

    return proc;
}

/**
 * Add process to ready queue
 */
static void add_to_ready_queue(process_t *proc) {
    if (!ready_queue) {
        ready_queue = proc;
        proc->next = NULL;
    } else {
        proc->next = ready_queue;
        ready_queue = proc;
    }
}

/**
 * Remove process from ready queue
 */
static process_t *remove_from_ready_queue(void) {
    if (!ready_queue) {
        return NULL;
    }
    process_t *proc = ready_queue;
    ready_queue = ready_queue->next;
    proc->next = NULL;
    return proc;
}

/**
 * Create init process (first user process)
 */
void process_create_init(void) {
    process_t *init = process_create(NULL);
    if (init) {
        init->pid = 1;
        init->state = PROCESS_READY;
        add_to_ready_queue(init);
        print_string("Init process (PID 1) created\n");
    }
}

/**
 * Process exit
 */
void process_exit(int status) {
    if (current_process) {
        current_process->state = PROCESS_TERMINATED;
        kfree(current_process->stack);
        current_process->stack = NULL;
        current_process = NULL;
    }
    (void)status; /* Status code handling */
}

/**
 * Get current process
 */
process_t *process_get_current(void) {
    return current_process;
}

/**
 * Set current process
 */
void process_set_current(process_t *proc) {
    current_process = proc;
    if (proc) {
        proc->state = PROCESS_RUNNING;
    }
}

/**
 * Round-robin scheduler
 */
void scheduler_schedule(void) {
    if (current_process && current_process->state == PROCESS_RUNNING) {
        current_process->state = PROCESS_READY;
        add_to_ready_queue(current_process);
    }

    process_t *next = remove_from_ready_queue();
    if (next) {
        process_set_current(next);
    } else if (current_process) {
        /* Keep current process if no other ready */
        current_process->state = PROCESS_RUNNING;
    }
}

/**
 * Yield CPU to next process
 */
void scheduler_yield(void) {
    scheduler_schedule();
    /* Context switch would happen here */
}

/**
 * Start scheduler
 */
void scheduler_start(void) {
    if (ready_queue) {
        scheduler_schedule();
        /* In real implementation, would enable interrupts and start running */
    }
}
