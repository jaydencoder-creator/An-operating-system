/* MinOS Kernel - Virtual File System */

#ifndef VFS_H
#define VFS_H

#include <stddef.h>

#define MAX_FILES 256
#define MAX_PATH 256

/* File open flags */
#define O_RDONLY 0x0000
#define O_WRONLY 0x0001
#define O_RDWR   0x0002
#define O_CREAT  0x0100
#define O_TRUNC  0x0200
#define O_APPEND 0x0400

/* File descriptor */
typedef struct {
    int inode;
    int offset;
    int flags;
    int refcount;
} file_descriptor_t;

/* VFS operations */
void vfs_init(void);
int vfs_open(const char *path, int flags);
int vfs_close(int fd);
int vfs_read(int fd, void *buf, size_t count);
int vfs_write(int fd, const void *buf, size_t count);
int vfs_seek(int fd, int offset, int whence);
size_t vfs_get_size(int fd);

#endif /* VFS_H */
