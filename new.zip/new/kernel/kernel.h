/* MinOS Kernel - Main Header */

#ifndef KERNEL_H
#define KERNEL_H

/* Kernel entry point */
void kernel_main(void);

/* Version information */
void kernel_get_version(int *major, int *minor, int *patch);
int kernel_is_initialized(void);

#endif /* KERNEL_H */
